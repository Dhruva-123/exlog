from .core import log, detect_framework

__all__ = [
    "log",
    "detect_framework"
]
